﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace lab3
{
    public class CafeCl
    {
        string Name;
        string Address;
        int TimeCost;
        int PlaceCost;
        int Size;
        ManagerCl Manager;
        List<TypeFestivalCl> ListFestival;

        public void setCaleName(string _Name)
        {
            Name = _Name;
        }
        public string getCafeName()
        {
            return Name;
        }
        public void setCafeAddress(string _Address)
        {
            Address = _Address;
        }
        public string getCafeAddress()
        {
            return Address;
        }
        public void setCafeTimeCost(int _TimeCost)
        {
            TimeCost = _TimeCost;
        }
        public int getCafeTimeCost()
        {
            return TimeCost;
        }
        public void setCafePlaceCost(int _PlaceCost)
        {
            PlaceCost = _PlaceCost;
        }
        public int getCafePlaceCost()
        {
            return PlaceCost;
        }
        public void setCafeSize(int _Size)
        {
            Size = _Size;
        }
        public int getCafeSize()
        {
            return Size;
        }
        public void setCafeManager(ManagerCl _Manager)
        {
            Manager = _Manager;
        }
        public ManagerCl getCafeManager()
        {
            return Manager;
        }
        public void setCafeListFestival(List<TypeFestivalCl> _ListFestival)
        {
            ListFestival = _ListFestival;
        }
        public List<TypeFestivalCl> getCafeListFestival()
        {
            return ListFestival;
        }
    }
}
