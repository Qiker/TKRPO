﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace lab3
{
    public class StatusCl
    {
        string Name;

        public void setStatusName(string _Name)
        {
            Name = _Name;
        }
        public string getStatusName()
        {
            return Name;
        }
    }
}
