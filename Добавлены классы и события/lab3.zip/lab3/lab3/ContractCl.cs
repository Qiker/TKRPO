﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace lab3
{
    public class ContractCl
    {
        string Number;
        TypeFestivalCl Festival;
        DateTime DateApply;
        DateTime DateStart;
        DateTime DateEnd;
        int Length;
        ClientCl Client;
        List<LeaderCl> ListLeader;
        List<AssistantCl> ListAssistant;
        List<DesignCl> ListDesign;
        List<CafeCl> ListCafe;
        string Hope;
        string Comment;
        int Deposit;
        StatusCl Status;

    }
}
