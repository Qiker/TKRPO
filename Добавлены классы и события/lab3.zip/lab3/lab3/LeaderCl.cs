﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace lab3
{
    public class LeaderCl
    {
        string Family;
        string Name;
        string Parent;
        DateTime BDay;
        string Phone;
        List<TypeFestivalCl> ListFestival;

        public void setLeaderFamily(string _Family)
        {
            Family = _Family;
        }
        public string getLeaderFamily()
        {
            return Family;
        }
        public void setLeaderName(string _Name)
        {
            Name = _Name;
        }
        public string getLeaderName()
        {
            return Name;
        }
        public void setLeaderParent(string _Parent)
        {
            Parent = _Parent;
        }
        public string getLeaderParent()
        {
            return Parent;
        }
        public void setLeaderBDay(DateTime _BDay)
        {
            BDay = _BDay;
        }
        public DateTime getLeaderBDay()
        {
            return BDay;
        }
        public void setLeaderPhone(string _Phone)
        {
            Phone = _Phone;
        }
        public string getLeaderPhone()
        {
            return Phone;
        }
        public void setLeaderListFestival(List<TypeFestivalCl> _ListFestival)
        {
            ListFestival = _ListFestival;
        }
        public List<TypeFestivalCl> getLeaderListFestival()
        {
            return ListFestival;
        }
    }
}
