﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace lab3
{
    public class ClientCl
    {
        string Family;
        string Name;
        string Parent;
        string Phone;
        int PersonCount;

        public void setClientFamily(string _Family)
        {
            Family = _Family;
        }
        public string getClientFamily()
        {
            return Family;
        }
        public void setClientName(string _Name)
        {
            Name = _Name;
        }
        public string getClientName()
        {
            return Name;
        }
        public void setClientParent(string _Parent)
        {
            Parent = _Parent;
        }
        public string getClientParent()
        {
            return Parent;
        }
        public void setClientPhone(string _Phone)
        {
            Phone = _Phone;
        }
        public string getClientPhone()
        {
            return Phone;
        }
        public void setClientPersonCount(int _PersonCount)
        {
            PersonCount = _PersonCount;
        }
        public int getClientPersonCount()
        {
            return PersonCount;
        }
    }
}
