﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace lab3
{
    public class TypeFestivalCl
    {
        string Name;

        public void setTypeFestivalName(string _Name)
        {
            Name = _Name;
        }
        public string getTypeFestivalName()
        {
            return Name;
        }
    }
}
