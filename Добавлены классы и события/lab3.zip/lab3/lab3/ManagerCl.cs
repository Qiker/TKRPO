﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace lab3
{
    public class ManagerCl
    {
        string Family;
        string Name;
        string Parent;
        string Phone;

        public void setManagerFamily(string _Family)
        {
            Family = _Family;
        }
        public string getManagerFamily()
        {
            return Family;
        }
        public void setManagerName(string _Name)
        {
            Name = _Name;
        }
        public string getManagerName()
        {
            return Name;
        }
        public void setManagerParent(string _Parent)
        {
            Parent = _Parent;
        }
        public string getManagerParent()
        {
            return Parent;
        }
        public void setManagerPhone(string _Phone)
        {
            Phone = _Phone;
        }
        public string getManagerPhone()
        {
            return Phone;
        }
    }
}
