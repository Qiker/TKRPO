﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace lab3
{
    public class DesignCl
    {
        string Name;
        int Cost;

        public void setDesignName(string _Name)
        {
            Name = _Name;
        }
        public string getDesignName()
        {
            return Name;
        }
        public void setDesignName(int _Cost)
        {
            Cost = _Cost;
        }
        public int getDesignCost()
        {
            return Cost;
        }
    }
}
