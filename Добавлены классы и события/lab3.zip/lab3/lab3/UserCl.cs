﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace lab3
{
    public class UserCl
    {
        string Name;
        LeaderCl Leader;
        AssistantCl Assistant;
        CafeCl Cafe;
        DesignCl Design;
        List<LeaderCl> ListLeader;
        List<AssistantCl> ListAssistant;
        List<CafeCl> ListCafe;
        List<DesignCl> ListDesign;
        List<TypeFestivalCl> ListTypeFestival;
        List<StatusCl> ListStatus;

    }
}
