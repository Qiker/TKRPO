﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace lab3
{
    public class AssistantCl
    {
        string Family;
        string Name;
        string Parent;
        DateTime BDay;
        string Phone;
        List<string> ListWork;

        public void setAssistantFamily(string _Family)
        {
            Family = _Family;
        }
        public string getAssistantFamily()
        {
            return Family;
        }
        public void setAssistantName(string _Name)
        {
            Name = _Name;
        }
        public string getAssistantName()
        {
            return Name;
        }
        public void setAssistantParent(string _Parent)
        {
            Parent = _Parent;
        }
        public string getAssistantParent()
        {
            return Parent;
        }
        public void setAssistantBDay(DateTime _BDay)
        {
            BDay = _BDay;
        }
        public DateTime getAssistantBDay()
        {
            return BDay;
        }
        public void setAssistantPhone(string _Phone)
        {
            Phone = _Phone;
        }
        public string getAssistantPhone()
        {
            return Phone;
        }
        public void setAssistantListWork(List<string> _ListWork)
        {
            ListWork = _ListWork;
        }
        public List<string> getAssistantListWork()
        {
            return ListWork;
        }
    }
}
