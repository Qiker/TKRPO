/*
Created		18.04.2014
Modified		19.04.2014
Project		
Model		
Company		
Author		
Version		
Database		mySQL 5 
*/




Create table TableTypeFestival (
	PKTypeFestival Int NOT NULL AUTO_INCREMENT,
	Name Varchar(200),
 Primary Key (PKTypeFestival)) ENGINE = InnoDB;

Create table TableStatus (
	PKStatus Int NOT NULL AUTO_INCREMENT,
	Name Varchar(100),
 Primary Key (PKStatus)) ENGINE = InnoDB;

Create table TableLeader (
	PKLeader Int NOT NULL AUTO_INCREMENT,
	Family Varchar(100),
	Name Varchar(100),
	Parent Varchar(100),
	BDay Date,
	Phone Varchar(20),
 Primary Key (PKLeader)) ENGINE = InnoDB;

Create table TableLeaderFestivals (
	PKLeaderFestivals Int NOT NULL AUTO_INCREMENT,
	PKLeader Int NOT NULL,
	PKTypeFestival Int NOT NULL,
 Primary Key (PKLeaderFestivals,PKLeader)) ENGINE = InnoDB;

Create table TableAssistant (
	PKAssistant Int NOT NULL AUTO_INCREMENT,
	Family Varchar(100),
	Name Varchar(100),
	Parent Varchar(100),
	BDay Date,
	Phone Varchar(20),
 Primary Key (PKAssistant)) ENGINE = InnoDB;

Create table TableSkill (
	PKSkill Int NOT NULL AUTO_INCREMENT,
	PKAssistant Int NOT NULL,
	Name Varchar(200),
 Primary Key (PKSkill,PKAssistant)) ENGINE = InnoDB;

Create table TableManager (
	PKManager Int NOT NULL AUTO_INCREMENT,
	PKCafe Int NOT NULL,
	Family Varchar(100),
	Name Varchar(100),
	Parent Varchar(100),
	Phone Varchar(20),
 Primary Key (PKManager)) ENGINE = InnoDB;

Create table TableCafe (
	PKCafe Int NOT NULL AUTO_INCREMENT,
	Name Varchar(100),
	Address Varchar(200),
	TimeCost Int,
	PlaceCost Int,
	Size Int,
 Primary Key (PKCafe)) ENGINE = InnoDB;

Create table TableCafeFestivals (
	PKCafeFestivals Int NOT NULL AUTO_INCREMENT,
	PKCafe Int NOT NULL,
	PKTypeFestival Int NOT NULL,
 Primary Key (PKCafeFestivals,PKCafe)) ENGINE = InnoDB;

Create table TableDesign (
	PKDesign Int NOT NULL AUTO_INCREMENT,
	Name Varchar(100),
	Cost Int,
 Primary Key (PKDesign)) ENGINE = InnoDB;

Create table TableClient (
	PKClient Int NOT NULL AUTO_INCREMENT,
	Family Varchar(100),
	Name Varchar(100),
	Parent Varchar(100),
	Phone Varchar(20),
	PersonCount Int,
 Primary Key (PKClient)) ENGINE = InnoDB;

Create table TableContract (
	PKContract Int NOT NULL AUTO_INCREMENT,
	PKStatus Int NOT NULL,
	PKClient Int NOT NULL,
	PKTypeFestival Int NOT NULL,
	Number Varchar(50),
	DateApply Datetime,
	DateStart Datetime,
	DateEnd Datetime,
	Length Int,
	Hope Text,
	Comment Text,
	Deposit Int,
 Primary Key (PKContract)) ENGINE = InnoDB;

Create table TableListLeader (
	PKListLeader Int NOT NULL AUTO_INCREMENT,
	PKLeader Int NOT NULL,
	PKContract Int NOT NULL,
	Status Int,
 Primary Key (PKListLeader,PKContract)) ENGINE = InnoDB;

Create table TableListAssistant (
	PKListAssistant Int NOT NULL AUTO_INCREMENT,
	PKContract Int NOT NULL,
	PKAssistant Int NOT NULL,
	Status Int,
 Primary Key (PKListAssistant,PKContract)) ENGINE = InnoDB;

Create table TableListCafe (
	PKListCafe Int NOT NULL AUTO_INCREMENT,
	PKContract Int NOT NULL,
	PKCafe Int NOT NULL,
	Status Int,
 Primary Key (PKListCafe,PKContract)) ENGINE = InnoDB;

Create table TableListDesign (
	PKListAssistant Int NOT NULL AUTO_INCREMENT,
	PKContract Int NOT NULL,
	PKDesign Int NOT NULL,
 Primary Key (PKListAssistant,PKContract)) ENGINE = InnoDB;


















