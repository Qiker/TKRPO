﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace lab3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            //ведущие
            System.Windows.Forms.Form f1 = new First();
            f1.Owner = this;
            f1.ShowDialog();
     
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            //исполнители
            System.Windows.Forms.Form f2 = new Second();
            f2.Owner = this;
            f2.ShowDialog();
     
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            //кафе
            System.Windows.Forms.Form f3 = new Cafe();
            f3.Owner = this;
            f3.ShowDialog();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            //оформления
            System.Windows.Forms.Form f4 = new Visual();
            f4.Owner = this;
            f4.ShowDialog();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            //отчёт
            System.Windows.Forms.Form f5 = new Report();
            f5.Owner = this;
            f5.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //добавить
            System.Windows.Forms.Form f6 = new Contract();
            f6.Owner = this;
            f6.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //редактировать
            System.Windows.Forms.Form f7 = new Contract();
            f7.Owner = this;
            f7.ShowDialog();
        }
    }
}
